package com.electronicstore.view.screens;

import com.electronicstore.App;
import com.electronicstore.view.components.AlertDialog;
import javafx.fxml.FXMLLoader;
import javafx.scene.layout.BorderPane;
import java.io.IOException;

public class InventoryManagementView extends BorderPane {
    private static final String FXML_PATH = "/fxml/InventoryManagement.fxml";
    private final App app;
    private InventoryManagementController controller;

    public InventoryManagementView(App app) {
        this.app = app;
        loadFXML();
    }

    private void loadFXML() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(FXML_PATH));
            BorderPane view = loader.load();
            controller = loader.getController();
            controller.setApp(app);

            setTop(view.getTop());
            setCenter(view.getCenter());
            setRight(view.getRight());
            getStyleClass().addAll(view.getStyleClass());

        } catch (IOException e) {
            e.printStackTrace();
            AlertDialog.showError("Error", "Failed to load inventory management view");
        }
    }
}
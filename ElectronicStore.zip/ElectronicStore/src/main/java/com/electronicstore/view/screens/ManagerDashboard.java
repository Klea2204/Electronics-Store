package com.electronicstore.view.screens;

import com.electronicstore.App;
import com.electronicstore.controller.InventoryController;
import com.electronicstore.controller.ReportController;
import com.electronicstore.model.inventory.Item;
import com.electronicstore.view.components.AlertDialog;
import com.electronicstore.view.components.SalesChart;
import com.electronicstore.view.components.StockLevelIndicator;
import javafx.event.ActionEvent;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.*;

import java.time.LocalDate;
import java.util.List;
import javafx.fxml.FXML;

public class ManagerDashboard {
    @FXML private BorderPane rootPane;
    @FXML private Label welcomeLabel;
    @FXML private DatePicker startDate;
    @FXML private DatePicker endDate;
    @FXML private SalesChart salesChart;
    @FXML private VBox inventoryCard;
    @FXML private VBox alertsBox;
    @FXML private Label totalItemsLabel;
    @FXML private Label totalValueLabel;
    @FXML private Label categoriesLabel;
    @FXML private Label suppliersLabel;
    @FXML private ListView<String> recentActivitiesList;

    private App app;
    private InventoryController inventoryController;
    private ReportController reportController;

    public ManagerDashboard() {
        inventoryController = new InventoryController();
        reportController = new ReportController();
    }

    public void setApp(App app) {
        this.app = app;
        initialize();
    }

    @FXML
    private void initialize() {
        if (app != null) {  // Only initialize if app is set
            welcomeLabel.setText("Welcome, " + app.getCurrentUser().getName());
            startDate.setValue(LocalDate.now().minusMonths(1));
            endDate.setValue(LocalDate.now());
            refreshDashboard();
        }
    }

    @FXML
    private void handleNewItem() {
        showNewItemDialog();
    }

    @FXML
    private void handleManageInventory() {
        app.showInventoryManagement();
    }

    @FXML
    private void handleManageSuppliers() {
        showSupplierManagement();
    }

    @FXML
    private void handleManageCategories() {
        showCategoryManagement();
    }

    @FXML
    private void handleViewReports() {
        showReports();
    }

    private void showReports() {
    }

    @FXML
    private void handleApplyDateFilter() {
        updateReports(startDate.getValue(), endDate.getValue());
    }

    private void updateInventoryStats() {
        List<Item> items = inventoryController.getAllItems();
        double totalValue = items.stream()
                .mapToDouble(item -> item.getSellingPrice() * item.getStockQuantity())
                .sum();

        totalItemsLabel.setText(String.format("Total Items: %d", items.size()));
        totalValueLabel.setText(String.format("Total Value: $%.2f", totalValue));
        categoriesLabel.setText(String.format("Categories: %d",
                inventoryController.getAllCategories().size()));
        suppliersLabel.setText(String.format("Suppliers: %d",
                inventoryController.getAllSuppliers().size()));
    }

    private void showNewItemDialog() {
        if (inventoryController.getAllCategories().isEmpty()) {
            AlertDialog.showError("Error", "Please add at least one category before adding items.");
            return;
        }

        if (inventoryController.getAllSuppliers().isEmpty()) {
            AlertDialog.showError("Error", "Please add at least one supplier before adding items.");
            return;
        }

        Dialog<Void> dialog = new Dialog<>();
        dialog.setTitle("Add New Item");
        dialog.setDialogPane(new AddItemDialog(inventoryController));
        dialog.showAndWait();
        refreshDashboard();
    }

    private VBox createRightSection() {
        VBox rightSection = new VBox(15);
        rightSection.setPrefWidth(300);
        rightSection.getStyleClass().add("dashboard-sidebar");

        Label alertsTitle = new Label("Stock Alerts");
        alertsTitle.getStyleClass().add("card-title");

        alertsBox = new VBox(10);
        alertsBox.getStyleClass().add("alerts-container");
        ScrollPane scrollPane = new ScrollPane(alertsBox);
        scrollPane.setFitToWidth(true);
        scrollPane.getStyleClass().add("alerts-scroll");

        rightSection.getChildren().addAll(alertsTitle, scrollPane);
        return rightSection;
    }

    private void refreshDashboard() {
        // Update inventory card
        updateInventoryCard();

        // Update stock alerts
        List<Item> lowStockItems = inventoryController.checkLowStock();
        updateStockAlerts(lowStockItems);

        // Update sales chart with latest data
        updateSalesChart();
    }

    private void updateStockAlerts(List<Item> lowStockItems) {
        alertsBox.getChildren().clear();

        if (lowStockItems.isEmpty()) {
            Label noAlertsLabel = new Label("No stock alerts");
            noAlertsLabel.getStyleClass().add("no-alerts-label");
            alertsBox.getChildren().add(noAlertsLabel);
        } else {
            for (Item item : lowStockItems) {
                createAlertCard(item);
            }
        }
    }

    private void createAlertCard(Item item) {
        VBox alertCard = new VBox(5);
        alertCard.getStyleClass().add("alert-card");

        Label itemName = new Label(item.getName());
        itemName.getStyleClass().add("alert-title");

        StockLevelIndicator stockIndicator = new StockLevelIndicator();
        stockIndicator.updateStockLevel(
                item.getStockQuantity(),
                item.getCategory().getMinStockLevel()
        );

        Button orderButton = new Button("Order More");
        orderButton.setOnAction(e -> orderMoreStock(item));

        alertCard.getChildren().addAll(itemName, stockIndicator, orderButton);
        alertsBox.getChildren().add(alertCard);
    }

    private void updateInventoryCard() {
        inventoryCard.getChildren().clear();
        Label inventoryTitle = new Label("Inventory Statistics");
        inventoryTitle.getStyleClass().add("card-title");
        inventoryCard.getChildren().add(inventoryTitle);

        List<Item> items = inventoryController.getAllItems();

        if (items.isEmpty()) {
            VBox emptyState = new VBox(10);
            emptyState.setAlignment(Pos.CENTER);

            Label emptyLabel = new Label("No items in inventory");
            emptyLabel.getStyleClass().add("empty-state-label");

            Button addItemButton = new Button("Add Your First Item");
            addItemButton.getStyleClass().addAll("button", "button-primary");
            addItemButton.setOnAction(e -> showNewItemDialog());

            emptyState.getChildren().addAll(emptyLabel, addItemButton);
            inventoryCard.getChildren().add(emptyState);
        } else {
            // Show inventory statistics
            Label totalItems = new Label(String.format("Total Items: %d", items.size()));
            Label totalValue = new Label(String.format("Total Value: $%.2f",
                    items.stream().mapToDouble(item -> item.getSellingPrice() * item.getStockQuantity()).sum()));

            inventoryCard.getChildren().addAll(totalItems, totalValue);
        }
    }

    private void orderMoreStock(Item item) {
        Dialog<Void> dialog = new Dialog<>();
        dialog.setTitle("Order Stock");
        dialog.setHeaderText("Order more stock for: " + item.getName());

        // Create the content
        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new javafx.geometry.Insets(20, 150, 10, 10));

        TextField quantityField = new TextField();
        quantityField.setPromptText("Enter quantity to order");

        grid.add(new Label("Current Stock:"), 0, 0);
        grid.add(new Label(String.valueOf(item.getStockQuantity())), 1, 0);
        grid.add(new Label("Minimum Level:"), 0, 1);
        grid.add(new Label(String.valueOf(item.getCategory().getMinStockLevel())), 1, 1);
        grid.add(new Label("Order Quantity:"), 0, 2);
        grid.add(quantityField, 1, 2);

        dialog.getDialogPane().setContent(grid);

        ButtonType orderButtonType = new ButtonType("Order", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().addAll(orderButtonType, ButtonType.CANCEL);

        // Enable/Disable order button depending on the validity of quantity
        Button orderButton = (Button) dialog.getDialogPane().lookupButton(orderButtonType);
        orderButton.setDisable(true);

        quantityField.textProperty().addListener((obs, oldVal, newVal) -> {
            orderButton.setDisable(newVal.trim().isEmpty() || !newVal.matches("\\d+") ||
                    Integer.parseInt(newVal.trim()) <= 0);
        });

        dialog.setResultConverter(dialogButton -> {
            if (dialogButton == orderButtonType) {
                try {
                    int quantity = Integer.parseInt(quantityField.getText().trim());
                    if (inventoryController.updateItemStock(item.getId(), quantity)) {
                        AlertDialog.showInfo("Success", "Stock order placed successfully.");
                        refreshDashboard();
                    } else {
                        AlertDialog.showError("Error", "Failed to place stock order.");
                    }
                } catch (NumberFormatException e) {
                    AlertDialog.showError("Error", "Invalid quantity entered.");
                }
            }
            return null;
        });

        dialog.showAndWait();
    }

    private void updateSalesChart() {
        if (startDate.getValue() != null && endDate.getValue() != null) {
            // Get sales data from report controller
//            var salesData = reportController.getSalesData(startDate.getValue(), endDate.getValue());
//            salesChart.updateChart(salesData);
        }
    }

    private void showSupplierManagement() {
        Dialog<Void> dialog = new Dialog<>();
        dialog.setTitle("Supplier Management");
        dialog.setDialogPane(new SupplierManagementDialog(inventoryController));
        dialog.showAndWait();
        refreshDashboard();
    }

    private void showCategoryManagement() {
        Dialog<Void> dialog = new Dialog<>();
        dialog.setTitle("Category Management");
        dialog.setDialogPane(new CategoryManagementDialog(inventoryController));
        dialog.showAndWait();
        refreshDashboard();
    }

    @FXML
    public void handleGenerateReport(ActionEvent actionEvent) {
        Dialog<Void> dialog = new Dialog<>();
        dialog.setTitle("Generate Report");

        GridPane grid = new GridPane();
        grid.getStylesheets().add(getClass().getResource("/styles/main.css").toExternalForm());
        grid.getStyleClass().add("dialog-pane");
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new javafx.geometry.Insets(20, 150, 10, 10));

        ComboBox<String> reportTypeCombo = new ComboBox<>();
        reportTypeCombo.getItems().addAll(
                "Sales Report",
                "Inventory Report",
                "Low Stock Report",
                "Profit Report"
        );
        reportTypeCombo.setPromptText("Select report type");

        DatePicker reportStartDate = new DatePicker(LocalDate.now().minusMonths(1));
        DatePicker reportEndDate = new DatePicker(LocalDate.now());

        grid.add(new Label("Report Type:"), 0, 0);
        grid.add(reportTypeCombo, 1, 0);
        grid.add(new Label("Start Date:"), 0, 1);
        grid.add(reportStartDate, 1, 1);
        grid.add(new Label("End Date:"), 0, 2);
        grid.add(reportEndDate, 1, 2);

        dialog.getDialogPane().setContent(grid);

        ButtonType generateButtonType = new ButtonType("Generate", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().addAll(generateButtonType, ButtonType.CANCEL);

        Button generateButton = (Button) dialog.getDialogPane().lookupButton(generateButtonType);
        generateButton.setDisable(true);

        reportTypeCombo.valueProperty().addListener((obs, oldVal, newVal) ->
                generateButton.setDisable(newVal == null));

        dialog.setResultConverter(dialogButton -> {
            if (dialogButton == generateButtonType) {
                try {
                    String report = reportController.generateReport(
                            reportTypeCombo.getValue(),
                            reportStartDate.getValue(),
                            reportEndDate.getValue()
                    );

                    if (report != null) {
                        showReportDialog(report, reportTypeCombo.getValue());
                    } else {
                        AlertDialog.showError("Error", "Failed to generate report.");
                    }
                } catch (Exception e) {
                    AlertDialog.showError("Error", "Error generating report: " + e.getMessage());
                }
            }
            return null;
        });

        dialog.showAndWait();
    }

    private void showReportDialog(String report, String title) {
        Dialog<Void> dialog = new Dialog<>();
        dialog.setTitle(title);
        dialog.setResizable(true);

        TextArea textArea = new TextArea(report);
        textArea.setEditable(false);
        textArea.setWrapText(true);
        textArea.setPrefRowCount(20);
        textArea.setPrefColumnCount(50);

        dialog.getDialogPane().setContent(textArea);
        dialog.getDialogPane().getButtonTypes().add(ButtonType.CLOSE);

        Button exportButton = new Button("Export");
        exportButton.setOnAction(e -> {
            if (reportController.exportReport(report, title)) {
                AlertDialog.showInfo("Success", "Report exported successfully.");
            } else {
                AlertDialog.showError("Error", "Failed to export report.");
            }
        });

        ((ButtonBar) dialog.getDialogPane().lookup(".button-bar")).getButtons().add(exportButton);

        dialog.showAndWait();
    }

    @FXML
    public void handleExportData(ActionEvent actionEvent) {
        Dialog<Void> dialog = new Dialog<>();
        dialog.setTitle("Export Data");

        VBox content = new VBox(10);
        content.setPadding(new javafx.geometry.Insets(20, 150, 10, 10));

        CheckBox itemsCheckBox = new CheckBox("Export Items");
        CheckBox categoriesCheckBox = new CheckBox("Export Categories");
        CheckBox suppliersCheckBox = new CheckBox("Export Suppliers");
        CheckBox salesCheckBox = new CheckBox("Export Sales Data");

        content.getChildren().addAll(
                new Label("Select data to export:"),
                itemsCheckBox,
                categoriesCheckBox,
                suppliersCheckBox,
                salesCheckBox
        );

        dialog.getDialogPane().setContent(content);

        ButtonType exportButtonType = new ButtonType("Export", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().addAll(exportButtonType, ButtonType.CANCEL);

        Button exportButton = (Button) dialog.getDialogPane().lookupButton(exportButtonType);
        exportButton.setDisable(true);

        // Enable export button if at least one checkbox is selected
        javafx.beans.binding.BooleanBinding noneSelected = itemsCheckBox.selectedProperty().not()
                .and(categoriesCheckBox.selectedProperty().not())
                .and(suppliersCheckBox.selectedProperty().not())
                .and(salesCheckBox.selectedProperty().not());
        exportButton.disableProperty().bind(noneSelected);

        dialog.setResultConverter(dialogButton -> {
            if (dialogButton == exportButtonType) {
                try {
                    boolean success = reportController.exportData(
                            itemsCheckBox.isSelected(),
                            categoriesCheckBox.isSelected(),
                            suppliersCheckBox.isSelected(),
                            salesCheckBox.isSelected()
                    );

                    if (success) {
                        AlertDialog.showInfo("Success", "Data exported successfully.");
                    } else {
                        AlertDialog.showError("Error", "Failed to export data.");
                    }
                } catch (Exception e) {
                    AlertDialog.showError("Error", "Error exporting data: " + e.getMessage());
                }
            }
            return null;
        });

        dialog.showAndWait();
    }

    private void updateReports(LocalDate start, LocalDate end) {
        if (start != null && end != null) {
            if (start.isAfter(end)) {
                AlertDialog.showError("Error", "Start date must be before end date.");
                return;
            }

            // Update sales chart
            updateSalesChart();

            // Update recent activities
            List<String> activities = reportController.getRecentActivities(start, end);
            recentActivitiesList.getItems().clear();
            recentActivitiesList.getItems().addAll(activities);

            // Update inventory value for the period
            double periodValue = reportController.calculateInventoryValue(start, end);
            totalValueLabel.setText(String.format("Period Value: $%.2f", periodValue));
        }
    }
}
package com.electronicstore.controller;

import com.electronicstore.model.inventory.Item;
import com.electronicstore.model.sales.Bill;
import com.electronicstore.model.sales.SaleItem;
import com.electronicstore.model.utils.FileHandler;
import com.electronicstore.model.utils.SessionState;
import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.logging.Logger;
import java.util.logging.Level;

public class BillingController {
    private static final String BILLS_FILE = "bills.dat";
    private static final Logger LOGGER = Logger.getLogger(BillingController.class.getName());
    private final SessionState sessionState;
    private final InventoryController inventoryController;
    private Bill currentBill;
    private StringBuilder errorMessage;

    public BillingController() {
        this.sessionState = SessionState.getInstance();
        this.inventoryController = new InventoryController();
        this.errorMessage = new StringBuilder();
    }

    public Bill createNewBill() {
        if (!sessionState.isCashier()) {
            LOGGER.warning("Non-cashier attempted to create bill");
            throw new IllegalStateException("Only cashiers can create bills");
        }
        String billNumber = "B" + UUID.randomUUID().toString().substring(0, 8);
        currentBill = new Bill(billNumber, sessionState.getCurrentUser().getId());
        LOGGER.info("Created new bill: " + billNumber);
        return currentBill;
    }

    public boolean addItemToBill(Item item, int quantity) {
        if (currentBill == null) {
            LOGGER.warning("Attempted to add item to null bill");
            errorMessage.append("No active bill found. ");
            return false;
        }

        if (!item.checkAvailability(quantity)) {
            LOGGER.warning("Insufficient stock for item: " + item.getId());
            errorMessage.append("Insufficient stock available. Current stock: " +
                    item.getStockQuantity() + ". ");
            return false;
        }

        SaleItem saleItem = new SaleItem(item, quantity);
        currentBill.addItem(saleItem);
        LOGGER.info("Added item to bill: " + item.getName() + " x" + quantity);
        return true;
    }

    public boolean finalizeBill() {
        if (currentBill == null || currentBill.getItems().isEmpty()) {
            LOGGER.warning("Attempted to finalize empty/null bill");
            errorMessage.append("Cannot finalize empty bill. ");
            return false;
        }

        try {
            LOGGER.info("Starting bill finalization process...");

            // Verify stock availability
            for (SaleItem saleItem : currentBill.getItems()) {
                Item item = saleItem.getItem();
                if (!item.checkAvailability(saleItem.getQuantity())) {
                    LOGGER.warning("Stock verification failed for item: " + item.getId());
                    errorMessage.append("Insufficient stock for item: " + item.getName() + ". ");
                    return false;
                }
            }

            // Update stock levels
            boolean success = true;
            for (SaleItem saleItem : currentBill.getItems()) {
                Item item = saleItem.getItem();
                if (!inventoryController.updateItemStock(item.getId(), saleItem.getQuantity())) {
                    LOGGER.severe("Failed to update stock for item: " + item.getId());
                    success = false;
                    break;
                }
                LOGGER.info("Updated stock for item: " + item.getId() +
                        " Quantity deducted: " + saleItem.getQuantity());
            }

            if (!success) {
                LOGGER.severe("Rolling back stock updates due to failure");
                rollbackStockUpdates();
                errorMessage.append("Failed to update inventory. Transaction rolled back. ");
                return false;
            }

            // Save bill
            List<Bill> bills = loadBills();
            bills.add(currentBill);
            FileHandler.saveListToFile(bills, BILLS_FILE);
            FileHandler.exportBill(currentBill);

            LOGGER.info("Bill finalized successfully: " + currentBill.getBillNumber());
            currentBill = null;
            return true;

        } catch (IOException e) {
            LOGGER.log(Level.SEVERE, "Error finalizing bill", e);
            errorMessage.append("System error occurred. Please try again. ");
            rollbackStockUpdates();
            return false;
        }
    }

    private List<Bill> loadBills() {
        try {
            return FileHandler.readListFromFile(BILLS_FILE);
        } catch (IOException | ClassNotFoundException e) {
            LOGGER.log(Level.SEVERE, "Error loading bills", e);
            return new ArrayList<>();
        }
    }

    private void rollbackStockUpdates() {
        if (currentBill == null) return;

        LOGGER.info("Starting stock rollback...");
        for (SaleItem saleItem : currentBill.getItems()) {
            Item item = saleItem.getItem();
            try {
                int originalQuantity = item.getStockQuantity() + saleItem.getQuantity();
                if (!inventoryController.updateItemStock(item.getId(), originalQuantity)) {
                    LOGGER.severe("Failed to rollback stock for item: " + item.getId());
                }
            } catch (Exception e) {
                LOGGER.log(Level.SEVERE, "Error during rollback for item: " + item.getId(), e);
            }
        }
    }

    public String getLastError() {
        String error = errorMessage.toString();
        errorMessage.setLength(0);
        return error;
    }

    public List<Bill> getDailyBills() {
        List<Bill> allBills = loadBills();
        return allBills.stream()
                .filter(bill -> bill.getDate().equals(LocalDate.now()))
                .filter(bill -> bill.getCashierId().equals(
                        sessionState.getCurrentUser().getId()))
                .toList();
    }
}
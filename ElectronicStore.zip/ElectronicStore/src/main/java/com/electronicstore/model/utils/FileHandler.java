package com.electronicstore.model.utils;

import com.electronicstore.model.sales.Bill;
import java.io.*;
import java.nio.file.*;
import java.util.List;
import java.util.ArrayList;

public class FileHandler {
    public static final String DATA_DIRECTORY = "store_data";
    private static final String BILLS_DIRECTORY = DATA_DIRECTORY + "/bills";

    static {
        try {
            // Create necessary directories if they don't exist
            Files.createDirectories(Paths.get(DATA_DIRECTORY));
            Files.createDirectories(Paths.get(BILLS_DIRECTORY));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Generic method to save object to binary file
    public static <T extends Serializable> void saveToFile(T object, String filename)
            throws IOException {
        String filepath = DATA_DIRECTORY + "/" + filename;
        try (ObjectOutputStream oos = new ObjectOutputStream(
                new FileOutputStream(filepath))) {
            oos.writeObject(object);
        }
    }

    // Generic method to read object from binary file
    @SuppressWarnings("unchecked")
    public static <T extends Serializable> T readFromFile(String filename)
            throws IOException, ClassNotFoundException {
        String filepath = DATA_DIRECTORY + "/" + filename;
        try (ObjectInputStream ois = new ObjectInputStream(
                new FileInputStream(filepath))) {
            return (T) ois.readObject();
        }
    }

    // Method to save list of objects to binary file
    public static <T extends Serializable> void saveListToFile(List<T> list, String filename)
            throws IOException {
        String filepath = DATA_DIRECTORY + "/" + filename;
        System.out.println("Saving to file: " + filepath);
        try (ObjectOutputStream oos = new ObjectOutputStream(
                new FileOutputStream(filepath))) {
            oos.writeObject(list);
            System.out.println("Successfully saved " + list.size() + " items");
        }
    }

    // Method to read list of objects from binary file
    @SuppressWarnings("unchecked")
    public static <T extends Serializable> List<T> readListFromFile(String filename)
            throws IOException, ClassNotFoundException {
        return (List<T>) readFromFile(filename);
    }

    // Method to export bill to text file
    public static void exportBill(Bill bill) throws IOException {
        String billFileName = String.format("%s/%s_%s.txt",
                BILLS_DIRECTORY,
                bill.getBillNumber(),
                bill.getDateTime().toLocalDate());

        String billContent = bill.generatePrintableFormat();
        Files.write(Paths.get(billFileName),
                billContent.getBytes(),
                StandardOpenOption.CREATE,
                StandardOpenOption.TRUNCATE_EXISTING);
    }

    // Method to save data to text file
    public static void saveToTextFile(String content, String filename) throws IOException {
        String filepath = DATA_DIRECTORY + "/" + filename;
        Files.write(Paths.get(filepath),
                content.getBytes(),
                StandardOpenOption.CREATE,
                StandardOpenOption.TRUNCATE_EXISTING);
    }

    // Method to read data from text file
    public static String readFromTextFile(String filename) throws IOException {
        String filepath = DATA_DIRECTORY + "/" + filename;
        return new String(Files.readAllBytes(Paths.get(filepath)));
    }

    // Method to list all files in a directory
    public static List<String> listFiles(String directory) {
        String dirPath = DATA_DIRECTORY + "/" + directory;
        try {
            return Files.list(Paths.get(dirPath))
                    .map(Path::getFileName)
                    .map(Path::toString)
                    .toList();
        } catch (IOException e) {
            e.printStackTrace();
            return new ArrayList<>();
        }
    }
}